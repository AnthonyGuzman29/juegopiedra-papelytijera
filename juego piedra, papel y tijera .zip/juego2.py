# se importa libreria 
import random

print("bienvenido al juego de piedra,papel y tijera")
print("Estas listo")

def jugar():
    opciones = ["piedra", "papel", "tijera"]
    usuario = input("Elige piedra, papel o tijera: ").lower()
    computadora = random.choice(opciones)
    
    print(f"Computadora eligió: {computadora}")
    
    # codigo de logica para la comparacion entre papel, tijera.
    if usuario == computadora:
        return "Es un empate"
    elif (usuario == "piedra" and computadora == "tijera") or \
         (usuario == "papel" and computadora == "piedra") or \
         (usuario == "tijera" and computadora == "papel"):
        return "¡Ganaste que bien !"
    else:
        return "Perdiste que pena jajaj"

# Ejecución
print(jugar())